"""Numerical stress tests for the candidate Dirichlet U-calibration proof."""

from __future__ import annotations

import itertools
import math

import numpy as np


RNG = np.random.default_rng(20260804)


def brier(p: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    f = 1.0 - np.sum(p * p, axis=1)
    losses = 1.0 + np.sum(p * p, axis=1, keepdims=True) - 2.0 * p
    return f, losses


def spherical(p: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    norm = np.linalg.norm(p, axis=1)
    return -norm, -p / norm[:, None]


def minimum_coordinate(p: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    active = np.argmin(p, axis=1)
    f = p[np.arange(len(p)), active]
    losses = np.zeros_like(p)
    losses[np.arange(len(p)), active] = 1.0
    return f, losses


def binary_v(p: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    assert p.shape[1] == 2
    return minimum_coordinate(p)


def dirichlet_identity(alpha: np.ndarray, j: int, loss_fn, samples: int = 1_000_000):
    if loss_fn is brier:
        n = alpha.sum()
        second_moment = np.sum(alpha * (alpha + 1.0)) / (n * (n + 1.0))
        lhs = 1.0 + second_moment - 2.0 * alpha[j] / n
        deleted = alpha.copy()
        deleted[j] -= 1.0
        nd = deleted.sum()
        if nd == 0:
            f_deleted = 0.0
        else:
            f_deleted = 1.0 - np.sum(deleted * (deleted + 1.0)) / (nd * (nd + 1.0))
        f_alpha = 1.0 - second_moment
        rhs = n * f_alpha - (n - 1.0) * f_deleted
        return float(lhs), float(rhs), 0.0
    p = RNG.dirichlet(alpha, size=samples)
    f, losses = loss_fn(p)
    n = alpha.sum()
    deleted = alpha.copy()
    deleted[j] -= 1
    active = deleted > 0
    if deleted.sum() == 0:
        f_deleted_samples = np.zeros(samples)
    elif active.sum() == 1:
        q = np.zeros((1, len(alpha)))
        q[0, np.flatnonzero(active)[0]] = 1.0
        f_deleted_samples = np.full(samples, float(loss_fn(q)[0][0]))
    else:
        q = np.zeros((samples, len(alpha)))
        q[:, active] = RNG.dirichlet(deleted[active], size=samples)
        f_deleted_samples = loss_fn(q)[0]
    lhs = float(losses[:, j].mean())
    rhs = float(n * f.mean() - (n - 1) * f_deleted_samples.mean())
    # The LHS and first RHS term share draws. Account for that covariance.
    residual_samples = losses[:, j] - n * f + (n - 1) * f_deleted_samples
    se = float(residual_samples.std() / math.sqrt(samples))
    return lhs, rhs, se


def tv_check(alpha: np.ndarray, j: int, samples: int = 2_000_000):
    p = RNG.dirichlet(alpha, size=samples)
    n, m = alpha.sum(), alpha[j]
    estimate = 0.5 * np.mean(np.abs(n * p[:, j] / m - 1.0))
    variance_bound = 0.5 * math.sqrt((n - m) / (m * (n + 1)))
    coarse_bound = 0.5 / math.sqrt(m)
    return estimate, variance_bound, coarse_bound


def binary_exact_expected_regret(sequence: tuple[int, ...], loss_fn, samples=250_000):
    # Monte Carlo only over fresh Dirichlet draws. The comparator is exact.
    total = np.zeros(samples)
    counts = np.zeros(2, dtype=int)
    for t, y in enumerate(sequence, start=1):
        if t == 1:
            p = np.full((samples, 2), 0.5)
        elif np.count_nonzero(counts) == 1:
            p = np.zeros((samples, 2))
            p[:, np.flatnonzero(counts)[0]] = 1.0
        else:
            p = RNG.dirichlet(counts, size=samples)
        total += loss_fn(p)[1][:, y]
        counts[y] += 1
    q = (np.asarray(counts) / len(sequence))[None, :]
    comparator = len(sequence) * float(loss_fn(q)[0][0])
    return float(total.mean() - comparator)


def main() -> None:
    cases = [
        (np.array([2.0, 3.0]), 0, brier, "binary Brier interior"),
        (np.array([1.0, 4.0]), 0, brier, "binary Brier alpha_j=1"),
        (np.array([1.0, 1.0]), 0, binary_v, "binary V alpha_j=1"),
        (np.array([3.0, 2.0]), 1, binary_v, "binary V interior"),
        (np.array([1.0, 2.0, 4.0]), 0, minimum_coordinate, "polyhedral K=3 boundary"),
        (np.array([2.0, 3.0, 4.0]), 1, minimum_coordinate, "polyhedral K=3 interior"),
        (np.array([1.0, 3.0, 2.0]), 0, spherical, "spherical boundary"),
        (np.array([2.0, 3.0, 4.0]), 2, spherical, "spherical interior"),
    ]
    print("DIRICHLET IDENTITY")
    for alpha, j, fn, name in cases:
        lhs, rhs, se = dirichlet_identity(alpha, j, fn)
        if se == 0.0:
            diagnostic = "exact"
        else:
            diagnostic = f"z={abs(lhs - rhs) / se:.2f}"
        print(f"{name:32s} lhs={lhs: .7f} rhs={rhs: .7f} diff={lhs-rhs:+.2e} {diagnostic}")

    print("\nTOTAL VARIATION")
    for alpha, j in [(np.array([1.0, 9.0]), 0), (np.array([2.0, 3.0]), 0),
                     (np.array([10.0, 5.0, 7.0]), 1)]:
        est, sharp, coarse = tv_check(alpha, j)
        print(f"alpha={alpha.astype(int)}, j={j}: estimate={est:.6f}, variance_bound={sharp:.6f}, coarse={coarse:.6f}")

    print("\nEXHAUSTIVE SHORT BINARY SEQUENCES")
    for fn, name in [(binary_v, "V"), (brier, "Brier")]:
        for horizon in range(1, 9):
            worst, arg = -math.inf, None
            for seq in itertools.product(range(2), repeat=horizon):
                reg = binary_exact_expected_regret(seq, fn, samples=20_000)
                if reg > worst:
                    worst, arg = reg, seq
            print(f"{name:5s} T={horizon}: worst EReg={worst:.5f}, 4sqrt(KT)={4*math.sqrt(2*horizon):.5f}, seq={arg}")


if __name__ == "__main__":
    main()
