Supplementary verification artifact for "Dirichlet Follow-the-Leader Closes the Gap in Simultaneous Multiclass U-Calibration."

Run:

    python verify_identities.py

Requirements: Python 3 and NumPy.

The script checks the count-deletion identity for Brier, spherical, binary V-shaped, and multiclass polyhedral proper losses. It also estimates the exact one-count total-variation expression and exhaustively tests all binary outcome sequences through horizon eight. Closed-form Brier cases are marked "exact". Monte Carlo cases report the discrepancy in estimated standard errors. The artifact is a sanity check and is not used by the proofs.
